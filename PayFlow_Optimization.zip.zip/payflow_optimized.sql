USE payflow_db;

-- 1. TRUY VẤN CỦ CỦA KẾ TOÁN (GÂY SẬP HỆ THỐNG - Non-SARGable)
EXPLAIN 
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT' 
  AND YEAR(created_at) = 2026 
  AND MONTH(created_at) = 6;

-- 2. TẠO COMPOSITE INDEX TỐI ƯU
CREATE INDEX idx_type_date ON Transactions(transaction_type, created_at);

-- 3. TRUY VẤN MỚI ĐÃ ĐƯỢC TỐI ƯU (SARGable Query)
EXPLAIN 
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT' 
  AND created_at >= '2026-06-01 00:00:00' 
  AND created_at < '2026-07-01 00:00:00';
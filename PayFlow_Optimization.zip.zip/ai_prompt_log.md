# Nhật Ký Tương Tác AI (AI Prompt Log)

### Prompt 1: Tìm hiểu về Non-SARGable
> **User:** Trong MySQL, nếu tôi tạo Index cho một cột ngày tháng, nhưng trong mệnh đề WHERE tôi lại viết `WHERE YEAR(col) = 2026`, tại sao MySQL lại từ chối sử dụng Index và phải quét toàn bộ bảng (Full Table Scan)?
>
> **AI:** Vì hàm `YEAR(col)` phải tính toán trên từng dòng dữ liệu để trả về giá trị năm trước khi so sánh. Điều này làm phá vỡ cấu trúc sắp xếp thứ tự của B-Tree Index (Non-SARGable), buộc MySQL phải quét toàn bộ bảng (Full Table Scan) thay vì dùng Index Seek.

---

### Prompt 2: Thứ tự cột trong Composite Index
> **User:** Khi thiết kế một Composite Index trong MySQL cho cột `(transaction_type, created_at)`, thứ tự các cột trong Index có quan trọng không?
>
> **AI:** Cực kỳ quan trọng (Quy tắc Leftmost Prefix). Cột dùng phép so sánh chính xác (=) nên đặt trước (`transaction_type`), cột dùng phép so sánh khoảng/range (`>=`, `<`) nên đặt sau (`created_at`) để thu hẹp vùng tìm kiếm tối đa.

---

### Prompt 3: Sự khác biệt trong cột Extra của EXPLAIN
> **User:** Trong kết quả EXPLAIN, cột 'Extra' hiện chữ 'Using index condition' khác gì với 'Using index'?
>
> **AI:** 
> - `Using index condition` (Index Condition Pushdown - ICP): Lọc dữ liệu bằng Index ở Storage Engine trước khi truy cập bảng gốc.
> - `Using index` (Covering Index): Toàn bộ dữ liệu cần SELECT nằm hoàn toàn trong Index, không cần đọc lại bảng dữ liệu gốc.
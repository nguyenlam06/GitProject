# Báo Cáo Phân Tích Hiệu Năng Truy Vấn (EXPLAIN Analysis)

## 1. So sánh Chỉ số EXPLAIN Trước và Sau Tối ưu

| Chỉ số EXPLAIN | Trước khi Tối ưu (Legacy) | Sau khi Tối ưu (Optimized) |
| :--- | :--- | :--- |
| **type** | `ALL` (Full Table Scan) | `range` |
| **possible_keys** | `NULL` | `idx_type_date` |
| **key** | `NULL` | `idx_type_date` |
| **rows** | ~5,000,000 (Toàn bộ bảng) | ~20,000 - 50,000 |
| **Extra** | `Using where` | `Using index condition` |

## 2. Nguyên nhân & Giải pháp Tối ưu

* **Nguyên nhân nghẽn:** Truy vấn cũ bọc cột `created_at` trong hàm `YEAR()` và `MONTH()`, khiến MySQL không thể duyệt B-Tree Index (Non-SARGable) và phải quét toàn bộ 5 triệu dòng (Full Table Scan), gây vọt 100% CPU.
* **Giải pháp áp dụng:** 
  1. Tạo Composite Index `idx_type_date(transaction_type, created_at)`.
  2. Viết lại mệnh đề `WHERE` dạng SARGable sử dụng khoảng thời gian: `created_at >= '2026-06-01 00:00:00' AND created_at < '2026-07-01 00:00:00'`.
* **Kết quả:** MySQL chuyển từ quét 5.000.000 dòng xuống chỉ còn quét các dòng trong khoảng ngày tháng 6, giảm thời gian phản hồi từ 45 giây xuống vài miligiây.